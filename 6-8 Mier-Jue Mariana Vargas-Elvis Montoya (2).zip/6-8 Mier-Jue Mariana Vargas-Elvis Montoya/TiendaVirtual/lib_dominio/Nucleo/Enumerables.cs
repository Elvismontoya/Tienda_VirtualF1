﻿namespace lib_dominio.Nucleo
{
    public class Enumerables
    {
        public enum Ventanas
        {
            Listas = 0,
            Editar = 1,
            Borrar = 2
        }
    }
}