﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lib_dominio.Entidades
{
    public class Envios
    {
        public int Id { get; set; }
        public string Codigo { get; set; }
        public string Tipo { get; set; }
        public string Estado { get; set; }
        public int Pedido { get; set; }
        public DateTime FechaEntrega { get; set; }
        [ForeignKey("Pedido")]
        public Pedidos? _Pedido { get; set; }

    }
}
