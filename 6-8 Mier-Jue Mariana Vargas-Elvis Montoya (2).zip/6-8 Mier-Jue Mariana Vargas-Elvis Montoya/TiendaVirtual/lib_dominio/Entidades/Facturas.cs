﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lib_dominio.Entidades
{
    public class Facturas
    {
        public int Id { get; set; }
        public string Codigo { get; set; }
        public DateTime FechaCompra { get; set; }
        public int Pedido { get; set; }
        public int Usuario { get; set; }
        public int Metodos_De_Pago { get; set; }
        public string Estado { get; set; }
        public decimal Total { get; set; }
        [ForeignKey("Pedido")]
        public Pedidos? _Pedido { get; set; }
        [ForeignKey("Usuario")]
        public Usuarios? _Usuario { get; set; }
        [ForeignKey("Metodos_De_Pago")]
        public Metodos_De_Pagos? _Metodos_De_Pago { get; set; }
        public List<Productos_Facturas> ProductosFactura { get; set; } = new List<Productos_Facturas>();

    }
}
