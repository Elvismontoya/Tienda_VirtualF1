﻿using lib_dominio.Entidades;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.ChangeTracking;

namespace lib_repositorios.Interfaces
{
    public interface IConexion
    {
        string? StringConexion { get; set; }

        public DbSet<Categorias> Categorias { get; set; }
        public DbSet<Usuarios> Usuarios { get; set; }
        public DbSet<Pedidos> Pedidos { get; set; }
        public DbSet<Envios> Envios { get; set; }
        public DbSet<Metodos_De_Pagos> Metodos_De_Pagos { get; set; }
        public DbSet<Facturas> Facturas { get; set; }
        public DbSet<Productos> Productos { get; set; }
        public DbSet<Productos_Facturas> Productos_Facturas { get; set; }

        EntityEntry<T> Entry<T>(T entity) where T : class;
        int SaveChanges();
    }
}