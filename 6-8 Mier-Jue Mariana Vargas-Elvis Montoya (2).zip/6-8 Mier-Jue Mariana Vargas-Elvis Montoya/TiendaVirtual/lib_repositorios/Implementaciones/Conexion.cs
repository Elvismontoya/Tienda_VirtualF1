﻿using lib_dominio.Entidades;
using lib_repositorios.Interfaces;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using System.Text.Json;

namespace lib_repositorios.Implementaciones
{
    public class Configuracion
    {
        public string StringConexion { get; set; }
    }
    public partial class Conexion : DbContext, IConexion
    {
        public string? StringConexion { get; set; }


        static string GetSolutionDirectory()
        {
            DirectoryInfo dir = new DirectoryInfo(Directory.GetCurrentDirectory());

            while (dir != null && !File.Exists(Path.Combine(dir.FullName, "TiendaVirtual.sln")))
            {
                dir = dir.Parent;
            }

            return dir?.FullName ?? throw new Exception("No se encontró la carpeta de la solución.");
        }
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            string filePath = Path.Combine(GetSolutionDirectory(), "Secret.json");

            string jsonContent = File.ReadAllText(filePath);
            var config = JsonSerializer.Deserialize<Configuracion>(jsonContent);


            StringConexion = config.StringConexion;
            optionsBuilder.UseSqlServer(this.StringConexion!, p => { });
            optionsBuilder.UseQueryTrackingBehavior(QueryTrackingBehavior.NoTracking);
        }

        public DbSet<Categorias> Categorias { get; set; }
        public DbSet<Usuarios> Usuarios { get; set; }
        public DbSet<Pedidos> Pedidos { get; set; }
        public DbSet<Envios> Envios { get; set; }
        public DbSet<Metodos_De_Pagos> Metodos_De_Pagos { get; set; }
        public DbSet<Facturas> Facturas { get; set; }
        public DbSet<Productos> Productos { get; set; }
        public DbSet<Productos_Facturas> Productos_Facturas { get; set; }
    }
}