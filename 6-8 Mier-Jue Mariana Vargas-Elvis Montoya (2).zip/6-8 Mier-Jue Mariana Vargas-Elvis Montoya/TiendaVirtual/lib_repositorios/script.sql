CREATE DATABASE Tienda_Virtual
GO
USE Tienda_Virtual
GO

CREATE TABLE Pedidos (
    Id INT IDENTITY(1,1) PRIMARY KEY,
    Codigo VARCHAR(50) NOT NULL,
    FechaCompra DATETIME NOT NULL,
    Direccion TEXT
);

CREATE TABLE Metodos_De_Pagos (
    Id INT IDENTITY(1,1) PRIMARY KEY,
    TipoPago VARCHAR(50) NOT NULL,
    Descripcion TEXT
);

CREATE TABLE Categorias (
    Id INT IDENTITY(1,1) PRIMARY KEY,
    Nombre VARCHAR(100) NOT NULL,
    Descripcion TEXT
);

CREATE TABLE Usuarios (
    Id INT IDENTITY(1,1) PRIMARY KEY,
    Codigo VARCHAR(50) NOT NULL,
    NombreCompleto VARCHAR(255) NOT NULL,
    Correo VARCHAR(255) NOT NULL,
    Direccion TEXT,
    Rol VARCHAR(50) NOT NULL,
    Telefono VARCHAR(20),
    Pedido INT NULL,
    FOREIGN KEY (Pedido) REFERENCES Pedidos(Id)
);

CREATE TABLE Envios (
    Id INT IDENTITY(1,1) PRIMARY KEY,
    Codigo VARCHAR(50) NOT NULL,
    Pedido INT NULL,
    Tipo VARCHAR(50) NOT NULL,
    Estado VARCHAR(50) NOT NULL,
    FechaEntrega DATETIME NOT NULL,
    FOREIGN KEY (Pedido) REFERENCES Pedidos(Id)
);

CREATE TABLE Facturas (
    Id INT IDENTITY(1,1) PRIMARY KEY,
    Codigo VARCHAR(50) NOT NULL,
    FechaCompra DATETIME NOT NULL,
    Pedido INT,
    Usuario INT,
    Metodos_De_Pago INT,
    Estado VARCHAR(50) NOT NULL,
    Total DECIMAL(10,2) NOT NULL,
    FOREIGN KEY (Pedido) REFERENCES Pedidos(Id),
    FOREIGN KEY (Usuario) REFERENCES Usuarios(Id),
    FOREIGN KEY (Metodos_De_Pago) REFERENCES Metodos_De_Pagos(Id)
);

CREATE TABLE Productos (
    Id INT IDENTITY(1,1) PRIMARY KEY,
    Nombre VARCHAR(100) NOT NULL,
    Precio DECIMAL(10,2) NOT NULL,
    Talla VARCHAR(20),
    Categoria INT,
    Material VARCHAR(100),
    FOREIGN KEY (Categoria) REFERENCES Categorias(Id)
);

CREATE TABLE Productos_Facturas (
    Id INT IDENTITY(1,1) PRIMARY KEY,
    Factura INT,
    Producto INT,
    Cantidad INT NOT NULL,
    IVA DECIMAL(5,2) NOT NULL,
    PrecioUnitario DECIMAL(10,2) NOT NULL,
    Total DECIMAL(10,2) NOT NULL,
    FOREIGN KEY (Factura) REFERENCES Facturas(Id),
    FOREIGN KEY (Producto) REFERENCES Productos(Id)
);

INSERT INTO [dbo].[Pedidos]([Codigo],[FechaCompra],[Direccion])
     VALUES
           ('P-101',GETDATE(),'cll 54 #88-14')

INSERT INTO [dbo].[Envios]([Codigo],[Pedido],[Tipo],[Estado],[FechaEntrega])
     VALUES
           ('EN-101',1,'Express','Enviado',GETDATE())

INSERT INTO [dbo].[Categorias]([Nombre],[Descripcion])
     VALUES
           ('Accesorios','Gorra')

INSERT INTO [dbo].[Metodos_De_Pagos]([TipoPago],[Descripcion])
     VALUES
           ('Transferencia','Tarjeta Debito')

INSERT INTO [dbo].[Productos]([Nombre],[Precio],[Talla],[Categoria],[Material])
     VALUES
           ('Gorra','80000','M',1,'Fibra')

INSERT INTO [dbo].[Usuarios]([Codigo],[NombreCompleto],[Correo],[Direccion],[Rol],[Telefono],[Pedido])
     VALUES
           ('1193','Prueba','Prueba@hot.com','Calle 10 # 10-10','Cliente','320561111',1)

INSERT INTO [dbo].[Facturas]([Codigo],[FechaCompra],[Pedido],[Usuario],[Metodos_De_Pago],[Estado],[Total])
     VALUES
		   ('F-102',GETDATE(),1,1,1,'Pendiente',80000)

INSERT INTO [dbo].[Productos_Facturas]([Factura],[Producto],[Cantidad],[IVA],[PrecioUnitario],[Total])
     VALUES
           (1,1,1,0.60,80000,80000)