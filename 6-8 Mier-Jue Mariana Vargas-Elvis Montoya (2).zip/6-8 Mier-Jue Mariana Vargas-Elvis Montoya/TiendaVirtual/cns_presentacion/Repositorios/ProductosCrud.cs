﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using lib_dominio.Entidades;
using lib_repositorios.Implementaciones;
using Microsoft.EntityFrameworkCore;

namespace cns_presentacion.Repositorios
{
    internal class ProductosCrud
    {

        //  private string string_conexion = "server=ELVIS\\DEV;database=Tienda_Virtual;Integrated Security=True;TrustServerCertificate=true;";

        public void SelectProd()
        {
            var conexion = new Conexion();

            // select * from PRODUCTOS
            Console.WriteLine("MOSTRAR PRODUCTOS");
            var lista_prod = conexion.Productos!.ToList();
            foreach (var entidad in lista_prod)
            {
                Console.WriteLine(entidad.Id + " | " +
                    entidad.Nombre + " | " +
                    entidad.Precio + " | " +
                    entidad.Talla + " | " +
                    entidad.Categoria + " | " +
                    entidad.Material);
            }
            Console.WriteLine(Environment.NewLine);
        }

        public void InsertProd()
        {
            var conexion = new Conexion();

            // Ingresar Productos
            var prod = new Productos()
            {
                Nombre = "Gorra",
                Precio = 20000,
                Talla = "M",
                Categoria = 1,
                Material = "Algodon"
            };
            conexion.Productos!.Add(prod);
            conexion.SaveChanges();
        }
        public void UpdateProd()
        {
            var conexion = new Conexion();

            var entidad = conexion.Productos!
                .FirstOrDefault(x => x.Id == 1);
            if (entidad == null)
                return;

            entidad.Talla = "L";

            var entry = conexion.Entry<Productos>(entidad);
            entry.State = EntityState.Modified;
            conexion.SaveChanges();
        }

        public void DeleteProd()
        {
            var conexion = new Conexion();

            var entidad = conexion.Productos!
                .FirstOrDefault(x => x.Id == 1);
            if (entidad == null)
                return;

            conexion.Productos!.Remove(entidad);
            conexion.SaveChanges();
        }

    }
}
