﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using lib_dominio.Entidades;
using lib_repositorios.Implementaciones;
using Microsoft.EntityFrameworkCore;

namespace cns_presentacion.Repositorios
{
    internal class PagosCrud
    {
        // private string string_conexion = "server=ELVIS\\DEV;database=Tienda_Virtual;Integrated Security=True;TrustServerCertificate=true;";

        public void SelectMet()
        {
            var conexion = new Conexion();


            // select * from METODOS PAGO
            Console.WriteLine("MOSTRAR METODOS DE PAGO");
            var lista_meto = conexion.Metodos_De_Pagos!.ToList();
            foreach (var entidad in lista_meto)
            {
                Console.WriteLine(entidad.Id + " | " +
                    entidad.TipoPago + " | " +
                    entidad.Descripcion);
            }
            Console.WriteLine(Environment.NewLine);
        }

        public void InsertMet()
        {
            var conexion = new Conexion();

            // Ingresar Metodos de Pago
            var metpag = new Metodos_De_Pagos()
            {
                TipoPago = "Efectivo",
                Descripcion = "Pago en efectivo"
            };
            conexion.Metodos_De_Pagos!.Add(metpag);
            conexion.SaveChanges();

        }

        public void UpdateMet()
        {
            var conexion = new Conexion();

            var entidad = conexion.Metodos_De_Pagos!
                .FirstOrDefault(x => x.TipoPago == "Transferencia");
            if (entidad == null)
                return;

            entidad.Descripcion = "PSE";

            var entry = conexion.Entry<Metodos_De_Pagos>(entidad);
            entry.State = EntityState.Modified;
            conexion.SaveChanges();
        }

        public void DeleteMet()
        {
            var conexion = new Conexion();

            var entidad = conexion.Metodos_De_Pagos!
                .FirstOrDefault(x => x.Id == 1);
            if (entidad == null)
                return;

            conexion.Metodos_De_Pagos!.Remove(entidad);
            conexion.SaveChanges();
        }
    }
}
