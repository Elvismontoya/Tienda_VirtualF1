﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using lib_dominio.Entidades;
using lib_repositorios.Implementaciones;
using Microsoft.EntityFrameworkCore;

namespace cns_presentacion.Repositorios
{
    internal class EnviosCrud
    {
       // private string string_conexion = "server=ELVIS\\DEV;database=Tienda_Virtual;Integrated Security=True;TrustServerCertificate=true;";

        public void SelectEnv()
        {
            var conexion = new Conexion();
            // conexion.StringConnection = this.string_conexion;

            // select * from ENVIOS
            Console.WriteLine("MOSTRAR ENVIOS");
            var lista_env = conexion.Envios!.ToList();
            foreach (var entidad in lista_env)
            {
                Console.WriteLine(entidad.Id + " | " +
                    entidad.Codigo + " | " +
                    entidad.Tipo + " | " +
                    entidad.Estado + " | " +
                    entidad.FechaEntrega + "|" +
                    entidad.Pedido);
            }
            Console.WriteLine(Environment.NewLine);

        }
        public void InsertEnv()
        {
            var conexion = new Conexion();
            //conexion.StringConnection = this.string_conexion;

            // Ingresar Envios
            var env = new Envios()
            {
                Codigo = "EN-101",
                Tipo = "Express",
                Estado = "Enviado",
                Pedido = 1,
                FechaEntrega = new DateTime(2025, 4, 24)
            };
            conexion.Envios!.Add(env);
            conexion.SaveChanges();
        }

        public void UpdateEnv()
        {
            var conexion = new Conexion();

            var entidad = conexion.Envios!
                .FirstOrDefault(x => x.Codigo == "EN-101");
            if (entidad == null)
                return;

            entidad.Estado = "Entregado";

            var entry = conexion.Entry<Envios>(entidad);
            entry.State = EntityState.Modified;
            conexion.SaveChanges();
        }

        public void DeleteEnv()
        {
            var conexion = new Conexion();
            // conexion.StringConnection = this.string_conexion;

            var entidad = conexion.Envios!
                .FirstOrDefault(x => x.Codigo == "EN-101");
            if (entidad == null)
                return;

            conexion.Envios!.Remove(entidad);
            conexion.SaveChanges();
        }
    }
}