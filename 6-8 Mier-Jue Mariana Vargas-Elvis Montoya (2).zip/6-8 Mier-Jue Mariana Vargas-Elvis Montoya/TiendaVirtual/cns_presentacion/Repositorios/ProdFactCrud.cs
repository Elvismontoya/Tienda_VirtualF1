﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using lib_dominio.Entidades;
using lib_repositorios.Implementaciones;
using Microsoft.EntityFrameworkCore;

namespace cns_presentacion.Repositorios
{
    internal class ProdFactCrud
    {
        //  private string string_conexion = "server=ELVIS\\DEV;database=Tienda_Virtual;Integrated Security=True;TrustServerCertificate=true;";

        public void SelectProFac()
        {
            var conexion = new Conexion();

            // select * from PRODUCTOS_FACTURAS
            Console.WriteLine("MOSTRAR PRODCUTOS-FACTURAS");
            var lista_profac = conexion.Productos_Facturas!.ToList();
            foreach (var entidad in lista_profac)
            {
                Console.WriteLine(entidad.Id + " | " +
                    entidad.Factura + " | " +
                    entidad.Producto + " | " +
                    entidad.Cantidad + " | " +
                    entidad.IVA + " | " +
                    entidad.PrecioUnitario + " | " +
                    entidad.Total);
            }
            Console.WriteLine(Environment.NewLine);
        }
        public void InsertProFac()
        {
            var conexion = new Conexion();

            // Ingresar productos_factura
            var profact = new Productos_Facturas()
            {
                Factura = 1,
                Producto = 1,
                Cantidad = 1,
                IVA = 0.6m,
                PrecioUnitario = 20000,
                Total = 20000
            };
            conexion.Productos_Facturas!.Add(profact);
            conexion.SaveChanges();

        }

        public void UpdateProFac()
        {
            var conexion = new Conexion();

            var entidad = conexion.Productos_Facturas!
                .FirstOrDefault(x => x.Factura == 1);
            if (entidad == null)
                return;

            entidad.Total = 90000;

            var entry = conexion.Entry<Productos_Facturas>(entidad);
            entry.State = EntityState.Modified;
            conexion.SaveChanges();
        }

        public void DeleteProFac()
        {
            var conexion = new Conexion();

            var entidad = conexion.Productos_Facturas!
                .FirstOrDefault(x => x.Factura == 1);
            if (entidad == null)
                return;

            conexion.Productos_Facturas!.Remove(entidad);
            conexion.SaveChanges();
        }
    }
}