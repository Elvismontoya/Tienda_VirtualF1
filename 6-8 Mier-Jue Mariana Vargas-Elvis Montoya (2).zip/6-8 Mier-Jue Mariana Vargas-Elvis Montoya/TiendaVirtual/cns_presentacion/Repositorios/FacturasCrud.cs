﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using lib_dominio.Entidades;
using lib_repositorios.Implementaciones;
using Microsoft.EntityFrameworkCore;

namespace cns_presentacion.Repositorios
{
    internal class FacturasCrud
    {

        //private string string_conexion = "server=ELVIS\\DEV;database=Tienda_Virtual;Integrated Security=True;TrustServerCertificate=true;";

        public void SelectFac()
        {
            var conexion = new Conexion();

            // select * from FACTURAS
            Console.WriteLine("MOSTRAR FACTURAS");
            var lista_fact = conexion.Facturas!.ToList();
            foreach (var entidad in lista_fact)
            {
                Console.WriteLine(entidad.Id + " | " +
                    entidad.Codigo + " | " +
                    entidad.FechaCompra + " | " +
                    entidad.Pedido + " | " +
                    entidad.Usuario + " | " +
                    entidad.Metodos_De_Pago + " | " +
                    entidad.Estado + " | " +
                    entidad.Total);
            }
            Console.WriteLine(Environment.NewLine);
        }

        public void InsertFac()
        {
            var conexion = new Conexion();


            // Ingresar Facturas
            var fact = new Facturas()
            {
                Codigo = "F-101",
                FechaCompra = DateTime.Now,
                Pedido = 1,
                Usuario = 1,
                Metodos_De_Pago = 1,
                Estado = "Pagado",
                Total = 20000
            };
            conexion.Facturas!.Add(fact);
            conexion.SaveChanges();
        }

        public void UpdateFac()
        {
            var conexion = new Conexion();

            var entidad = conexion.Facturas!
                .FirstOrDefault(x => x.Codigo == "F-101");
            if (entidad == null)
                return;

            entidad.Estado = "Pendiente";

            var entry = conexion.Entry<Facturas>(entidad);
            entry.State = EntityState.Modified;
            conexion.SaveChanges();
        }

        public void DeleteFac()
        {
            var conexion = new Conexion();


            var entidad = conexion.Facturas!
                .FirstOrDefault(x => x.Codigo == "F-101");
            if (entidad == null)
                return;

            conexion.Facturas!.Remove(entidad);
            conexion.SaveChanges();
        }
    }
}

