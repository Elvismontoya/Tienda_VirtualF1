﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using lib_dominio.Entidades;
using lib_repositorios.Implementaciones;
using Microsoft.EntityFrameworkCore;

namespace cns_presentacion.Repositorios
{
    internal class PedidosCrud
    {
        //private string string_conexion = "server=ELVIS\\DEV;database=Tienda_Virtual;Integrated Security=True;TrustServerCertificate=true;";

        public void SelectPed()
        {
            var conexion = new Conexion();
            //  conexion.StringConnection = this.string_conexion;

            // select * from PEDIDOS
            Console.WriteLine("MOSTRAR PEDIDOS");
            var lista_pedi = conexion.Pedidos!.ToList();
            foreach (var entidad in lista_pedi)
            {
                Console.WriteLine(entidad.Id + " | " +
                    entidad.Codigo + " | " +
                    entidad.FechaCompra + " | " +
                    entidad.Direccion);
            }
            Console.WriteLine(Environment.NewLine);
        }

        public void InsertPed()
        {
            var conexion = new Conexion();

            // Ingresar Pedidos
            var pedi = new Pedidos()
            {
                Codigo = "123456",
                FechaCompra = DateTime.Now,
                Direccion = "Calle 10 # 10-10"
            };
            conexion.Pedidos!.Add(pedi);
            conexion.SaveChanges();
        }

        public void UpdatePed()
        {
            var conexion = new Conexion();

            var entidad = conexion.Pedidos!
                .FirstOrDefault(x => x.Codigo == "P-101");
            if (entidad == null)
                return;

            entidad.Direccion = "Calle 27A # 32-54";

            var entry = conexion.Entry<Pedidos>(entidad);
            entry.State = EntityState.Modified;
            conexion.SaveChanges();
        }

        public void DeletePed()
        {
            var conexion = new Conexion();

            var entidad = conexion.Pedidos!
                .FirstOrDefault(x => x.Codigo == "P-101");
            if (entidad == null)
                return;

            conexion.Pedidos!.Remove(entidad);
            conexion.SaveChanges();
        }
    }
}
