﻿using System.Windows.Markup;
using lib_dominio.Entidades;
using lib_repositorios.Implementaciones;
using Microsoft.EntityFrameworkCore;

namespace cns_presentacion.Repositorios
{
    public class CategoriasCrud
    {
       // private string string_conexion = "server=ELVIS\\DEV;database=Tienda_Virtual;Integrated Security=True;TrustServerCertificate=true;";

        public void SelectCate()
        {
            var conexion = new Conexion();

            // select * from CATEGORIAS
            Console.WriteLine("MOSTRAR CATEGORIAS");
            var lista_categ = conexion.Categorias!.ToList();
            foreach (var entidad in lista_categ)
            {
                Console.WriteLine(entidad.Id + " | " +
                    entidad.Nombre + " | " +
                    entidad.Descripcion);
            }
            Console.WriteLine(Environment.NewLine);

        }

        public void InsertCate()
        {
            var conexion = new Conexion();

            // Ingresar Categorias
            var categ = new Categorias()
            {
                Nombre = "Accesorios",
                Descripcion = "Gorra"
            };
            conexion.Categorias!.Add(categ);
            conexion.SaveChanges();

        }

        public void UpdateCate()
        {
            var conexion = new Conexion();

            var entidad = conexion.Categorias!
                .FirstOrDefault(x => x.Nombre == "Accesorios");
            if (entidad == null)
                return;

            entidad.Descripcion = "Llavero";

            var entry = conexion.Entry<Categorias>(entidad);
            entry.State = EntityState.Modified;
            conexion.SaveChanges();
        }

        public void DeleteCate()
        {
            var conexion = new Conexion();

            var entidad = conexion.Categorias!
                .FirstOrDefault(x => x.Nombre == "Accesorios");
            if (entidad == null)
                return;

            conexion.Categorias!.Remove(entidad);
            conexion.SaveChanges();
        }
    }
}