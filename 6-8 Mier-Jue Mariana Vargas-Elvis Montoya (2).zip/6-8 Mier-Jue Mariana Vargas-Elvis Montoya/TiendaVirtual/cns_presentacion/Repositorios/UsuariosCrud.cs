﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using lib_dominio.Entidades;
using lib_repositorios.Implementaciones;
using Microsoft.EntityFrameworkCore;

namespace cns_presentacion.Repositorios
{
    internal class UsuariosCrud
    {
        //  private string string_conexion = "server=ELVIS\\DEV;database=Tienda_Virtual;Integrated Security=True;TrustServerCertificate=true;";

        public void SelectUser()
        {
            var conexion = new Conexion();
            //  conexion.StringConnection = this.string_conexion;

            // select * from Usuarios
            Console.WriteLine("MOSTRAR USUARIOS");
            var lista_usua = conexion.Usuarios!.ToList();
            foreach (var entidad in lista_usua)
            {
                Console.WriteLine(entidad.Id + " | " +
                    entidad.NombreCompleto + " | " +
                    entidad.Correo + " | " +
                    entidad.Direccion + " | " +
                    entidad.Rol + " | " +
                    entidad.Telefono + " | " +
                    entidad.Pedido);
            }
            Console.WriteLine(Environment.NewLine);
        }
        public void InsertUser()
        {
            var conexion = new Conexion();

            // Ingresar Usuarios
            var usua = new Usuarios()
            {
                Codigo = "1193036444",
                NombreCompleto = "Elvis Alberto Montoya Rondon",
                Correo = "elvisam08@gmail.com",
                Direccion = "Calle 10 # 10-10",
                Rol = "Cliente",
                Telefono = "3111234567",
                Pedido = 1
            };
            conexion.Usuarios!.Add(usua);
            conexion.SaveChanges();
        }

        public void UpdateUser()
        {
            var conexion = new Conexion();

            var entidad = conexion.Usuarios!
                .FirstOrDefault(x => x.Codigo == "1193");
            if (entidad == null)
                return;

            entidad.NombreCompleto = "Prueba2";

            var entry = conexion.Entry<Usuarios>(entidad);
            entry.State = EntityState.Modified;
            conexion.SaveChanges();
        }

        public void DeleteUser()
        {
            var conexion = new Conexion();

            var entidad = conexion.Usuarios!
                .FirstOrDefault(x => x.Codigo == "1193");
            if (entidad == null)
                return;

            conexion.Usuarios!.Remove(entidad);
            conexion.SaveChanges();
        }
    }
}
