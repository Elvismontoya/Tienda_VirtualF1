﻿using cns_presentacion.Core;
using cns_presentacion.Repositorios;
using lib_dominio.Entidades;

Console.WriteLine("Proyecto consola\n");


var app = new Aplicacion();
app.Run();

/*var conPed = new PedidosCrud();
var conEnv = new EnviosCrud();
var conUse = new UsuariosCrud();
var conPag = new PagosCrud();
var conCat = new CategoriasCrud();
var conProd = new ProductosCrud();
var conFac = new FacturasCrud();
var conProFac = new ProdFactCrud();

conPed.InsertPed();
conEnv.InsertEnv();
conUse.InsertUser();
conPag.InsertMet();
conCat.InsertCate();
conProd.InsertProd();
conFac.InsertFac();
conProFac.InsertProFac();

conCat.SelectCate();
conFac.SelectFac();

//conexion.Update_Cat();
//conexion.Select_Cat();

//conexion.Delete_Cat();
//conexion.Select_Cat();*/



