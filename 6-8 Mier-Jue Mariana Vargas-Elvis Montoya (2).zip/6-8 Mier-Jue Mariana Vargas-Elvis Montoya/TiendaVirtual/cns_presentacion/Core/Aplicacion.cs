﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using cns_presentacion.Repositorios;

namespace cns_presentacion.Core
{
    public class Aplicacion
    {

        private readonly PedidosCrud _conPed;
        private readonly EnviosCrud _conEnv;
        private readonly UsuariosCrud _conUse;
        private readonly PagosCrud _conPag;
        private readonly CategoriasCrud _conCat;
        private readonly ProductosCrud _conProd;
        private readonly FacturasCrud _conFac;
        private readonly ProdFactCrud _conProFac;

        public Aplicacion()
        {
            _conPed = new PedidosCrud();
            _conEnv = new EnviosCrud();
            _conUse = new UsuariosCrud();
            _conPag = new PagosCrud();
            _conCat = new CategoriasCrud();
            _conProd = new ProductosCrud();
            _conFac = new FacturasCrud();
            _conProFac = new ProdFactCrud();
        }

        public void Run()//LO QUE VA EJECUTAR
        {
            _conPed.InsertPed();
            _conEnv.InsertEnv();
            _conUse.InsertUser();
            _conPag.InsertMet();
            _conCat.InsertCate();
            _conProd.InsertProd();
            _conFac.InsertFac();
            _conProFac.InsertProFac();
            _conCat.SelectCate();
            _conFac.SelectFac();
            _conEnv.DeleteEnv();
            _conEnv.SelectEnv();

        }




    }
}
