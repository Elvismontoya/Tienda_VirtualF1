﻿using lib_dominio.Entidades;

namespace ut_presentacion.Nucleo
{
    public class EntidadesNucleo
    {
        public static Categorias? Categorias()
        {
            var entidadcat = new Categorias();
            entidadcat.Nombre = "Pruebas-" + DateTime.Now.ToString("yyyyMMddhhmmss");
            entidadcat.Descripcion = "Pruebas";
            return entidadcat;
        }

        public static Envios? Envios()
        {
            var entidadenv = new Envios();
            entidadenv.Estado = "Pruebas-" + DateTime.Now.ToString("yyyyMMddhhmmss");
            entidadenv.Codigo = "Pruebas";
            entidadenv.Tipo = "Pruebas";
            entidadenv.Pedido = 1;
            entidadenv.FechaEntrega = DateTime.Now;
            return entidadenv;
        }

        public static Pedidos? Pedidos()
        {
            var entidadped = new Pedidos();
            entidadped.Codigo = "Pruebas-" + DateTime.Now.ToString("yyyyMMddhhmmss");
            entidadped.Direccion = "Pruebas";
            entidadped.FechaCompra = DateTime.Now;
            return entidadped;
        }


        public static Usuarios? Usuarios()
        {
            var entidadusu = new Usuarios();
            entidadusu.Codigo = "Pruebas-" + DateTime.Now.ToString("yyyyMMddhhmmss");
            entidadusu.Direccion = "Pruebas";
            entidadusu.NombreCompleto = "Pruebas";
            entidadusu.Correo = "Pruebas";
            entidadusu.Rol = "Pruebas";
            entidadusu.Telefono = "Pruebas";
            entidadusu.Pedido = 1;
            return entidadusu;
        }

        public static Metodos_De_Pagos? Metodos_De_Pago()
        {
            var entidadmetp = new Metodos_De_Pagos();
            entidadmetp.TipoPago = "Pruebas-" + DateTime.Now.ToString("yyyyMMddhhmmss");
            entidadmetp.Descripcion = "Pruebas";
           
            return entidadmetp;
        }

        public static Productos? Productos()
        {
            var entidadprodu = new  Productos();
            entidadprodu.Nombre = "Pruebas-" + DateTime.Now.ToString("yyyyMMddhhmmss");
            entidadprodu.Precio = 100000;
            entidadprodu.Talla = "Pruebas";
            entidadprodu.Material = "Pruebas";
            entidadprodu.Categoria = 1;
            
            return entidadprodu;
        }


        public static Facturas? Facturas()
        {
            var entidadfac = new Facturas();
            entidadfac.Codigo = "Pruebas-" + DateTime.Now.ToString("yyyyMMddhhmmss");
            entidadfac.Usuario = 1;
            entidadfac.Pedido = 1;
            entidadfac.Metodos_De_Pago = 1;
            entidadfac.Estado = "";
            entidadfac.FechaCompra = DateTime.Now;
            entidadfac.Total = 100000;
            return entidadfac;
        }

        public static Productos_Facturas? Productos_Facturas()
        {
            var entidadprodufac = new Productos_Facturas();
            entidadprodufac.Producto = 1;
            entidadprodufac.PrecioUnitario = 100000;
            entidadprodufac.Cantidad = 1;
            entidadprodufac.Factura = 1;
            entidadprodufac.IVA = 0.6m;
            entidadprodufac.Total = 100000;

            return entidadprodufac;
        }



    }
}